package com.example.pmicrosevice.service;

import org.springframework.stereotype.Service;

import com.example.pmicrosevice.dto.ProductDetails;

@Service
public interface ProductService {

	public void saveProductDetails(ProductDetails productdetails);

}
