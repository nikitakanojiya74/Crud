package com.example.pmicrosevice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.pmicrosevice.dto.ProductDetails;
import com.example.pmicrosevice.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService productservice;
	
	@PostMapping("/product/save")
	
	public String saveProduct(@RequestBody ProductDetails productdetails) {
		try {
			productservice.saveProductDetails(productdetails);
		}catch(Exception e) {
			
			return"Failed";
		}
		return"Success";
	}
	
	
	
}
