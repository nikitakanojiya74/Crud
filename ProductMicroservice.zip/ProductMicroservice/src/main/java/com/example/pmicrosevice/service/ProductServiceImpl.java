package com.example.pmicrosevice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pmicrosevice.dto.ProductDetails;
import com.example.pmicrosevice.model.Product;
import com.example.pmicrosevice.model.ProductPrice;
import com.example.pmicrosevice.repository.ProductPriceRepository;
import com.example.pmicrosevice.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductPriceRepository productprice;
	@Autowired
	ProductRepository productrep;

	@Override
	public void saveProductDetails(ProductDetails productdetails) {
		// TODO Auto-generated method stub
		Product prdt=new Product();
		
		
		prdt.setId(productdetails.getId());
		prdt.setProductid(productdetails.getProductid());
		prdt.setName(productdetails.getName());
		prdt.setType(productdetails.getType());
		prdt.setCategory(productdetails.getCategory());
		prdt.setDescription(productdetails.getDescription());
		
		
		ProductPrice pp=new ProductPrice();
		pp.setPrice(productdetails.getPrice());
		pp.setProductid(productdetails.getProductid());
		
		
		productrep.save(prdt);
		productprice.save(pp);
		
		
		
		
	}

}
